/*

hallar los primos comprendidos entre el nro pedido
con uso de for anidados

 */
package pkg15_05_2019;
import java.io.*;
/**
 *
 * @author Navegador
 */
public class Pkg15_05_2019 {

    /**
     * @param args the command line arguments
     */
    int j,i,div,sum;
    boolean primo;
    
    public void primos(int valores){
        for(i=2;i<valores;i++){
            primo=true;
            for(j=2;j<i/2;j++){
                if(i%j==0){
                    primo=false;
                    break;
                }
            }
            if(primo){
                //el 4 no es primo
                if(i==4){
                    
                }else{
                    System.out.println(i + " * ");
                }
            }
        }
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
