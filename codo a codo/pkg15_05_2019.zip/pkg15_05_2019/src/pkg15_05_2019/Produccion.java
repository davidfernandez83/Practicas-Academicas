/*
Produccion en 30 dias
 */
package pkg15_05_2019;
import java.util.Scanner;
/**
 *
 * @author Navegador
 */
public class Produccion {
    public static void main(String[] args) {
        int produccion[] = new int[5],i;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("\n LEE LA PRODUCCION DE 5 DÍAS \n");
        //leer datos
        System.out.println("---------------------Lectura de datos----------------------");
        for(i=0;i<=4;i++){
            System.out.println("Teclee la produccion ["+i+"]");
            produccion[i]=sc.nextInt();
            
        }
        //imprime salida
        System.out.println("------------Resultados-------------");
        for(i=0;i<=4;i++){
            System.out.println("Produccion["+i+"] " + produccion[i]);
        }
    }
    
}
