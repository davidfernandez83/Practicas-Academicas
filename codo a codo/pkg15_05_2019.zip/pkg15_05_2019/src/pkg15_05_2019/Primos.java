/*
Que sume los primos
 */
package pkg15_05_2019;

/**
 *
 * @author Navegador
 */
public class Primos {
    public static void main(String[] args) {
        
        int primos[]={2,3,5,7,11,13,17,19};
        int suma=0,i;
        for(i=0;i<primos.length;i++){
            suma+=primos[i];
        }
        System.out.println("El total de la suma de los primos es: " + suma);
        System.out.println("Hay " + primos.length + " números primos");
        
    }
    
}
