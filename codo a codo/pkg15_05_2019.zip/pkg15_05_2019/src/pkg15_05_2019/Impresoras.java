/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg15_05_2019;

/**
 *
 * @author Navegador
 */
public class Impresoras {
    
    public static void main(String[] args) {
        int primos[]={2,3,5,7,11,13,17,19};
        String[] marcasImpresoras={"Brother","Canon","HP","Epson","Lexmark","Xerox","Samsung"};
        System.out.println("Hay " + marcasImpresoras.length + " marcas de impresoras");
        System.out.println("Hay " + primos.length + " números primos");
        int i;
        for(i=0;i<marcasImpresoras.length;i++){
            System.out.println("Son: " + marcasImpresoras[i]);
        }
        
    }
        
    
}
