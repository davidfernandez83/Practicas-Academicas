/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.Scanner;

/**
 *
 * @author Navegador
 */
public class NewClass {
   /* se ingresa un mes cualquiera luego verificar
            a que trimestre corresponde */

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int mes;
        System.out.println("Ingrese el número de mes: ");
        mes=teclado.nextInt();
        
        if(mes==1 || mes==2 || mes==3){
            System.out.println("Esta en el primer trimestre");
        }else{
             if(mes==4 || mes==5 || mes==6){
                System.out.println("Esta en el segundo trimestre");
               }else{
                    if(mes==7 || mes==8 || mes==9){
                    System.out.println("Esta en el tercer trimestre");
                    }else{
                        if(mes==10 || mes==11 || mes==12){
                        System.out.println("Esta en el cuarto trimestre");
                        }else{
                            System.out.println("Ingresó un numero incorrecto");
                        }
                        
                    }
             }
        }
    
}
}
