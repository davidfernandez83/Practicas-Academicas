/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author Navegador
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        int num1, num2, suma, multiplicacion;
        System.out.println("Ingrese el primer nùmero:");
        num1=teclado.nextInt();
        System.out.println("Ingrese el segundo nùmero:");
        num2=teclado.nextInt();
        if(num1>num2){
            suma=num1+num2;
            System.out.println("La suma es: "+suma);
        }else if(num1<num2){
            multiplicacion=num1*num2;
            System.out.println("La multiplicaciòn es: "+multiplicacion);
        }
    }
    
}
