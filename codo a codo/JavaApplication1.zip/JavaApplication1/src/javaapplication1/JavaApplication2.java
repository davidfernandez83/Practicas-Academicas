/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author Navegador
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    
        /*ingrese dos numeros pos de 1 o 2 dig
    que aparezca un mensaje con el numero y que diga cuantos digitos tiene
    si ingresa un numero no pedido que aparezca error
    */
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        int num1, num2, suma, multiplicacion;
        System.out.println("Ingrese el primer nùmero:");
        num1=teclado.nextInt();
        //System.out.println("Ingrese el segundo nùmero:");
        //num2=teclado.nextInt();5
        
        
        if(num1>=0&&num1<10){
            System.out.println("El número "+num1+" tiene un digito");
        }else{
            if(num1>=10&&num1<100){
                System.out.println("El número "+num1+" tiene dos digitos");
            }else{
                System.out.println("Ingresó un número fuera de rango");
            }
            
        }
        

        
    }
    
}
