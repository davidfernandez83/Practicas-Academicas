
package conectabbdd2;

public class Crud {
    
    
    
    
}
