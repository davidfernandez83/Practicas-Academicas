﻿namespace WebApplicationEjemploAPI.Models.Dtos
{
    public class ProductoDTO
    {
        private int id;
        private string nombre;
        private string descripcion;
        private double precio;


        public ProductoDTO() { }

        public ProductoDTO(Producto p)
        {
            this.id = p.Id;
            this.nombre = p.Nombre;
            this.descripcion = p.Descripcion;
            this.precio = p.Precio;
        }

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public double Precio { get => precio; set => precio = value; }
    }
}
