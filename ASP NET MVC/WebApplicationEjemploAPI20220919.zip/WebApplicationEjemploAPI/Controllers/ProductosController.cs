﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using WebApplicationEjemploAPI.DbContext;
using WebApplicationEjemploAPI.Models.Dtos;
using WebApplicationEjemploAPI.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplicationEjemploAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : ControllerBase
    {
        private MySqlDbContext mySqlDbContext;
        public ProductosController(MySqlDbContext mySqlDbContext)
        {
            this.mySqlDbContext = mySqlDbContext;
        }

        // GET: api/<ValuesController>
        [HttpGet]
        public IEnumerable<ProductoDTO> Get()
        {
            List<ProductoDTO> productosDTO = new List<ProductoDTO>();
            List<Producto> productos = mySqlDbContext.Productos.OrderBy(x => x.Nombre).ToList();
            foreach(Producto p in productos)
            {
                productosDTO.Add(new ProductoDTO(p));
            }

            return productosDTO;
        }

        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
        public ProductoDTO Get(int id)
        {
            Producto p = mySqlDbContext.Productos.Find(id);
            return new ProductoDTO(p);
        }

     
        // POST api/<ValuesController>
        [HttpPost]
        public void Post(ProductoDTO productoDTO)
        {
            Producto p = new Producto() { Nombre = productoDTO.Nombre, Descripcion = productoDTO.Descripcion, Precio = productoDTO.Precio };
            mySqlDbContext.Productos.Add(p);
            mySqlDbContext.SaveChanges();
        }

        // PUT api/<ValuesController>/5
        [HttpPut("{id}")]
        public void Put(int id, ProductoDTO productoDTO)
        {
            Producto p = mySqlDbContext.Productos.Find(id);
            p.Nombre = productoDTO.Nombre;
            p.Descripcion = productoDTO.Descripcion;
            p.Precio = productoDTO.Precio;
            mySqlDbContext.SaveChanges();
        }

        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            Producto p = mySqlDbContext.Productos.Find(id);
            mySqlDbContext.Productos.Remove(p);
            mySqlDbContext.SaveChanges();

        }
    }
}
