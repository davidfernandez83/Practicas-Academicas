﻿namespace WebApplicationEjemploAPI.DbContext
{
    using Microsoft.EntityFrameworkCore;

    public class MySqlDbContext : DbContext
    {
        public DbSet<Models.Producto> Productos { get; set; }
        public MySqlDbContext(DbContextOptions<MySqlDbContext> options) : base(options)
        {

        }
    }
}
