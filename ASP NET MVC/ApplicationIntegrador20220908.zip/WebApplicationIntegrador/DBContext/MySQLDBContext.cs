﻿using Microsoft.EntityFrameworkCore;

namespace WebApplicationIntegrador.DBContext
{
    public class MySQLDBContext : DbContext
    {
        public DbSet<Models.Producto> Productos { get; set; }
        public MySQLDBContext(DbContextOptions<MySQLDBContext> options) : base(options) {
        
        }
    }
}
