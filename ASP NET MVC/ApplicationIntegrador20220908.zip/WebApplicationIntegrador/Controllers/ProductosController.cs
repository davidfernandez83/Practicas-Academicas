﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using WebApplicationIntegrador.DBContext;
using WebApplicationIntegrador.Models;
using WebApplicationIntegrador.Models.ViewModel;

namespace WebApplicationIntegrador.Controllers
{
    public class ProductosController : Controller
    {

        private MySQLDBContext mySQLDBContext;

        public ProductosController(MySQLDBContext context)
        {
            mySQLDBContext = context;
        }

        // GET: ProductosController
        public ActionResult Index()
        {
            List<ProductoViewModel> productosViewModel = new List<ProductoViewModel>();
            List<Producto> productos = mySQLDBContext.Productos.OrderBy(x => x.Nombre).ToList();

            foreach(var p in productos)
            {
                productosViewModel.Add(new ProductoViewModel() { Id = p.Id, Nombre = p.Nombre, Descripcion = p.Descripcion, Precio = p.Precio });
            }

            return View(productosViewModel);
        }

        // GET: ProductosController/Details/5
        public ActionResult Details(int id)
        {
            //Producto producto = mySQLDBContext.Productos.Find(id);
            Producto producto = mySQLDBContext.Productos.FirstOrDefault(x => x.Id == id);
            var productoViewModel = new ProductoViewModel() { Id = producto.Id, Nombre = producto.Nombre, Descripcion = producto.Descripcion, Precio = producto.Precio };

            return View(productoViewModel);
        }

        // GET: ProductosController/Create
        public ActionResult Create()
        {
            var producto = new ProductoViewModel();
            return View(producto);
        }

        // POST: ProductosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ProductoViewModel productoViewModel)
        {
            if(ModelState.IsValid)
            {
                Producto producto = new Producto();
                producto.Nombre = productoViewModel.Nombre;
                producto.Descripcion = productoViewModel.Descripcion;
                producto.Precio = productoViewModel.Precio;
                mySQLDBContext.Productos.Add(producto);
                mySQLDBContext.SaveChanges();
                //TODO: Hacer el alta en la base de datos...
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: ProductosController/Edit/5
        public ActionResult Edit(int id)
        {
            //Producto producto = mySQLDBContext.Productos.Find(id);
            Producto producto = mySQLDBContext.Productos.FirstOrDefault(x => x.Id == id);
            var productoViewModel = new ProductoViewModel() { Id = producto.Id, Nombre = producto.Nombre, Descripcion = producto.Descripcion, Precio = producto.Precio };

            return View(productoViewModel);
        }

        // POST: ProductosController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, ProductoViewModel productoViewModel)
        {
            if (ModelState.IsValid)
            {
                Producto producto = mySQLDBContext.Productos.FirstOrDefault(x => x.Id == id);
                producto.Nombre = productoViewModel.Nombre;
                producto.Descripcion = productoViewModel.Descripcion;
                producto.Precio = productoViewModel.Precio;
                mySQLDBContext.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: ProductosController/Delete/5
        public ActionResult Delete(int id)
        {
            Producto producto = mySQLDBContext.Productos.FirstOrDefault(x => x.Id == id);
            mySQLDBContext.Productos.Remove(producto);
            mySQLDBContext.SaveChanges();
            return RedirectToAction(nameof(Index));
        }


    }
}
