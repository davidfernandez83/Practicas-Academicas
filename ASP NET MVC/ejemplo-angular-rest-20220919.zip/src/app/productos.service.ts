import { Injectable } from '@angular/core';
import { HttpClient } from  '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {

  urlBase = 'http://localhost:38190/api';

  constructor(private httpClient : HttpClient) {

  }

  getProductos() {
    return this.httpClient.get<Array<any>>(this.urlBase + '/productos');
  }

  getProducto(id : string) {
    return this.httpClient.get<any>(this.urlBase + '/productos/' + id);
  }

  postProducto(p : any) {
    return this.httpClient.post<any>(this.urlBase + '/productos', p);
  }
}
