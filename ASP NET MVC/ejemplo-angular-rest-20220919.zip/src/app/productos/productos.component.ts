import { Component, OnInit } from '@angular/core';
import { ProductosService } from '../productos.service';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.component.html',
  styleUrls: ['./productos.component.css']
})
export class ProductosComponent implements OnInit {

  titulo = "Listado de productos";

  producto =  { id: 0, nombre: null, precio: 0, descripcion: '' };
  productos : Array<any> = [];

  constructor(private productosService : ProductosService) { 
  }

  ngOnInit(): void {
    this.productosService.getProductos().subscribe((response) => {
      console.log(response);
      this.productos = response;
    }, (error) => {
      console.log('Hay un error', error);
    });
  }

  eventoClickAltaProducto() {
    this.productosService.postProducto(this.producto).subscribe((response) => {
      console.log('Listo alta');
    }, (error) => {
      console.log('Hay un error', error);
    });
  }

  eventoClickVerProducto(id : string) {
    this.productosService.getProducto(id).subscribe((response) => {
      this.producto = response;
    }, (error) => {
      console.log('Hay un error', error);
    });
  }


}
