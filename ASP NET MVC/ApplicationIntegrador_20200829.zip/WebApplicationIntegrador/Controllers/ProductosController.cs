﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using WebApplicationIntegrador.Models.ViewModel;

namespace WebApplicationIntegrador.Controllers
{
    public class ProductosController : Controller
    {
        // GET: ProductosController
        public ActionResult Index()
        {
            List<ProductoViewModel> productos = new List<ProductoViewModel>();
            productos.Add(new ProductoViewModel() { Id = 1, Nombre = "Test1", Descripcion = "Test1", Precio = 1000.0 });
            productos.Add(new ProductoViewModel() { Id = 2, Nombre = "Test2", Descripcion = "Test2", Precio = 1000.0 });
            productos.Add(new ProductoViewModel() { Id = 3, Nombre = "Test3", Descripcion = "Test3", Precio = 1000.0 });

            return View(productos);
        }

        // GET: ProductosController/Details/5
        public ActionResult Details(int id)
        {
            var producto = new ProductoViewModel() { Id = id, Nombre = "Test1", Descripcion = "Test1", Precio = 1000.0 };

            return View(producto);
        }

        // GET: ProductosController/Create
        public ActionResult Create()
        {
            var producto = new ProductoViewModel();
            return View(producto);
        }

        // POST: ProductosController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ProductoViewModel productoViewModel)
        {
            if(ModelState.IsValid)
            {
                //TODO: Hacer el alta en la base de datos...
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: ProductosController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ProductosController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductosController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ProductosController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
