﻿using System.ComponentModel.DataAnnotations;

namespace WebApplicationIntegrador.Models.ViewModel
{
    public class ProductoViewModel
    {
        private int id;
        private string nombre;
        private string descripcion;
        private double precio;

        public int Id { get => id; set => id = value; }

        [Required(ErrorMessage = "Falta completar el campo.")]
        public string Nombre { get => nombre; set => nombre = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public double Precio { get => precio; set => precio = value; }
    }
}
