﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace WebApplicationIntegrador.Models
{
    [Table("Productos")]
    public class Producto
    {
        private int id;
        private string nombre;
        private string descripcion;
        private double precio;

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get => id; set => id = value; }

        [Required]
        [MaxLength(250)]
        public string Nombre { get => nombre; set => nombre = value; }

        [MaxLength(250)]
        public string Descripcion { get => descripcion; set => descripcion = value; }

        [Required]
        public double Precio { get => precio; set => precio = value; }
    }
}
