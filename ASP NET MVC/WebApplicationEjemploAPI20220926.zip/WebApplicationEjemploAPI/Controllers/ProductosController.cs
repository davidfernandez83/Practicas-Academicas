﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using WebApplicationEjemploAPI.DbContext;
using WebApplicationEjemploAPI.Models.Dtos;
using WebApplicationEjemploAPI.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplicationEjemploAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : ControllerBase
    {
        private MySqlDbContext mySqlDbContext;
        public ProductosController(MySqlDbContext mySqlDbContext)
        {
            this.mySqlDbContext = mySqlDbContext;
        }

        // GET: api/<ValuesController>
        [HttpGet]
        public IEnumerable<ProductoDTO> Get()
        {
            List<ProductoDTO> productosDTO = new List<ProductoDTO>();
            List<Producto> productos = mySqlDbContext.Productos.OrderBy(x => x.Nombre).ToList();
            foreach(Producto p in productos)
            {
                productosDTO.Add(new ProductoDTO(p));
            }

            return productosDTO;
        }

        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            Producto p = mySqlDbContext.Productos.Find(id);

            if (p != null)
                return Ok(new ProductoDTO(p));
            else
                return NotFound();
            
        }

     
        // POST api/<ValuesController>
        [HttpPost]
        public IActionResult Post(ProductoDTO productoDTO)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Producto p = new Producto() { Nombre = productoDTO.Nombre, Descripcion = productoDTO.Descripcion, Precio = productoDTO.Precio };
            mySqlDbContext.Productos.Add(p);
            mySqlDbContext.SaveChanges();
            productoDTO.Id = p.Id;

            return Created("~api/productos/" + p.Id, productoDTO);
        }

        // PUT api/<ValuesController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, ProductoDTO productoDTO)
        {
            Producto p = mySqlDbContext.Productos.Find(id);
            p.Nombre = productoDTO.Nombre;
            p.Descripcion = productoDTO.Descripcion;
            p.Precio = productoDTO.Precio;
            mySqlDbContext.SaveChanges();
            return NoContent();
        }

        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            Producto p = mySqlDbContext.Productos.Find(id);
            mySqlDbContext.Productos.Remove(p);
            mySqlDbContext.SaveChanges();
            return NoContent();
        }
    }
}
