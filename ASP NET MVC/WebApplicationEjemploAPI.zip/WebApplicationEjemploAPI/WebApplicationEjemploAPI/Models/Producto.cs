﻿namespace WebApplicationEjemploAPI.Models
{
    public class Producto
    {
    }
}
