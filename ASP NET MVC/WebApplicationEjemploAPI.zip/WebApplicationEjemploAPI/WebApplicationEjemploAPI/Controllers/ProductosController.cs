﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using WebApplicationEjemploAPI.Models.Dtos;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplicationEjemploAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : ControllerBase
    {
        // GET: api/<ValuesController>
        [HttpGet]
        public IEnumerable<ProductoDTO> Get()
        {
            List<ProductoDTO> productosDTO = new List<ProductoDTO>();
            productosDTO.Add(new ProductoDTO() { Id = 1, Nombre = "Ejemplo1" });
            productosDTO.Add(new ProductoDTO() { Id = 2, Nombre = "Ejemplo2" });
            productosDTO.Add(new ProductoDTO() { Id = 2, Nombre = "Ejemplo3" });

            return productosDTO;
        }

        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
        public ProductoDTO Get(int id)
        {
            return new ProductoDTO() { Id = 1, Nombre = "Ejemplo1" };
        }

     
        // POST api/<ValuesController>
        [HttpPost]
        public void Post(ProductoDTO productoDTO)
        {

        }

        // PUT api/<ValuesController>/5
        [HttpPut("{id}")]
        public void Put(int id, ProductoDTO productoDTO)
        {
        }

        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
