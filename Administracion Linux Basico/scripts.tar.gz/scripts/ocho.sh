#!/bin/bash
#Estructura case 
read -p "Ingrese usuario: " USUARIO

case $USUARIO in 
juan)
echo Bienvenido $USUARIO
;;
pedro)
echo Bienvenido $USUARIO
;;
roberto)
echo Bienvenido $USUARIO
;;
*)
echo Usuario No valido
;;
esac

