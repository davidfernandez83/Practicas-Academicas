#!/bin/bash
function imprimir() {
echo Bienvenido $USUARIO
}

#Estructura case 
read -p "Ingrese usuario: " USUARIO
case $USUARIO in 
juan)
imprimir
;;
pedro)
imprimir
;;
roberto)
imprimir
;;
*)
echo Usuario No valido
;;
esac

