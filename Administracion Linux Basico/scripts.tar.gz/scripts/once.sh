#!/bin/bash
#Repetir para cada valor

for i in $(cat lista.txt)
	do
		mail $i -s "Envio de correo" < /etc/resolv.conf
		sleep 2
	done


