#!/bin/bash

clear

read -p "Ingrese su nombre: " NOMBRE

echo Bienvenido $NOMBRE
