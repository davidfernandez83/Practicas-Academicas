#!/bin/bash
clear
read -p "Ingrese un número: " NUM1
read -p "Ingrese otro número: " NUM2

if [ $NUM1  -eq  $NUM2  ] ; then
	echo $NUM1 \= $NUM2
elif [ $NUM1 -lt $NUM2 ] ; then
	echo $NUM1 \< $NUM2	
else
	echo $NUM1 \> $NUM2
fi
# -eq: es igual
# -lt: estrictamente menor que 
# -gt: estrictamente mayor que
# -le: menor o igual que
# -ge: mayor o igual que
# -ne: no es igual que

SUMA=$[$NUM1 + $NUM2] 
echo La suma de los números es $SUMA.


