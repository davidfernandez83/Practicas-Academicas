#!/bin/bash
clear
NOMBRE=$1
APELLIDO=$2

echo Hola $NOMBRE $APELLIDO
