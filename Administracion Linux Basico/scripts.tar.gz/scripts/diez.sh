#!/bin/bash
#Repetir para cada valor

for i in fabian juan pedro
	do
	echo hola $i
	sleep 2
	done


