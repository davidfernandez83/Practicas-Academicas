#!/bin/bash
clear
read -p "Ingrese su nombre: " NOMBRE

if [ $NOMBRE = "juan" ] ; then
		echo Bienvenido $NOMBRE
elif [ $NOMBRE = "pedro" ] ; then
		echo bienvenido $NOMBRE
elif [ $NOMBRE = "roberto" ] ; then
		echo bienvenido $NOMBRE
else
	echo Usuario no valido.
fi

