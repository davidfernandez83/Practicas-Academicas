#!/bin/bash
clear
read -p "Ingrese su nombre: " NOMBRE

if [ $NOMBRE = "juan" ] || [ $NOMBRE = "pedro" ] ; then

	echo Bienvenido $NOMBRE
else
	echo Usuario no valido.
fi

