#!/bin/bash
#Repetir para cada valor

for i in $(seq 1 254)
	do
		ping -c 1 192.168.0.$i > /dev/null
		ok=$?
		
		if [ $ok -eq 0 ] ; then
			echo el equipo 192.168.0.$i responde 
		fi		
		
	done


