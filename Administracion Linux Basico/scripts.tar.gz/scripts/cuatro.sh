#!/bin/bash
clear
read -p "Ingrese su nombre: " NOMBRE

if test $NOMBRE = "juan" ; then

	echo Bienvenido $NOMBRE
else
	echo Usuario no valido.
fi

