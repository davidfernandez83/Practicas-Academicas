-- GROUPING SETS
----------------

-- Listar la cantidad de turnos, agrupados independientemente de acuerdo a
-- la cobertura, al paciente, al m�dico, o a la fecha del turno
SELECT COUNT(*) AS [Cant Turnos],
       Fecha_turno,
       LEFT(M.Apellido+', '+M.Nombre,30) AS [M�dico],
       LEFT(P.Apellido+', '+P.Nombre,30) AS [Paciente],
       LEFT(isnull(C.Denominacion,'PRIVADO'),40) AS [Cobertura]       
FROM Consultorio_Medico.dbo.Cobertura_Social C
right join Consultorio_Medico.dbo.Paciente P
  on C.Id_Cobertura = P.Id_Cobertura
inner join Consultorio_Medico.dbo.Turno T
  on P.Id_Paciente = T.Id_Paciente
inner join Consultorio_Medico.dbo.Medico M
  on T.Id_Medico = M.Id_Medico
GROUP BY GROUPING SETS
  (Fecha_turno,
   LEFT(M.Apellido+', '+M.Nombre,30),
   LEFT(P.Apellido+', '+P.Nombre,30),
   LEFT(isnull(C.Denominacion,'PRIVADO'),40))
ORDER BY 2, 3, 4, 5


-- EJERCICIO 5:
-- Listar la cantidad de pacientes, agrupados independientemente de acuerdo a
-- la cobertura, o a la provincia de su domicilio


