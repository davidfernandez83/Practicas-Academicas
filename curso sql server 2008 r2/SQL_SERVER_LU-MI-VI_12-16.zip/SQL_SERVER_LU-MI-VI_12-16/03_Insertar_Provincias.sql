﻿USE [Consultorio_Medico]
GO

INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('BA', 'Buenos Aires')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('CC', 'Chaco')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('CD', 'Córdoba')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('CF', 'C.A.B.A.')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('CH', 'Chubut')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('CR', 'Corrientes')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('CT', 'Catamarca')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('ER', 'Entre Ríos')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('FO', 'Formosa')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('JY', 'Jujuy')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('LP', 'La Pampa')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('LR', 'La Rioja')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('MN', 'Misiones')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('MZ', 'Mendoza')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('NQ', 'Neuquén')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('RN', 'Río Negro')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('SA', 'Salta')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('SC', 'Santa Cruz')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('SE', 'Santiago del Estero')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('SF', 'Santa Fe')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('SJ', 'San Juan')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('SL', 'San Luis')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('TF', 'Tierra del Fuego, Antártida e Islas del Atlántico Sur')
INSERT INTO [dbo].[Provincia] ([Id_Provincia],[Nombre]) VALUES ('TM', 'Tucumán')
GO

