USE [Consultorio_Medico]
GO

/****** Object:  Table [dbo].[Cobertura_Social]    Script Date: 09/19/2014 10:29:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Cobertura_Social](
	[Id_Cobertura] [int] IDENTITY(1,1) NOT NULL,
	[Tipo_Cobertura] [nchar](2) NOT NULL,
	[RNOS] [int] NULL,
	[Denominacion] [nvarchar](200) NOT NULL,
	[Sigla] [nchar](20) NULL,
	[Domicilio] [nvarchar](200) NULL,
	[Localidad] [nvarchar](200) NULL,
	[CP] [nchar](8) NULL,
	[Id_Provincia] [nchar](2) NOT NULL,
	[Telefono] [nchar](15) NULL,
	[E_mail] [nvarchar](80) NULL,
	[Web] [nvarchar](80) NULL,
 CONSTRAINT [PK_Cobertura_Social] PRIMARY KEY CLUSTERED 
(
	[Id_Cobertura] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Cobertura_Social]  WITH CHECK ADD  CONSTRAINT [FK_Cobertura_Social_Provincia] FOREIGN KEY([Id_Provincia])
REFERENCES [dbo].[Provincia] ([Id_Provincia])
GO

ALTER TABLE [dbo].[Cobertura_Social] CHECK CONSTRAINT [FK_Cobertura_Social_Provincia]
GO


