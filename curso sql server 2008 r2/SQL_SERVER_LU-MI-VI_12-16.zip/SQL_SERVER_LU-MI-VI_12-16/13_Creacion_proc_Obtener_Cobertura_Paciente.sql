USE [Consultorio_Medico]
GO

/****** Object:  StoredProcedure [dbo].[Obtener_Cobertura_Paciente]    Script Date: 09/22/2014 09:58:47 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Obtener_Cobertura_Paciente]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Obtener_Cobertura_Paciente]
GO

USE [Consultorio_Medico]
GO

/****** Object:  StoredProcedure [dbo].[Obtener_Cobertura_Paciente]    Script Date: 09/22/2014 09:58:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Obtener_Cobertura_Paciente]
  (@Cod_Paciente int)
AS

DECLARE @Cod_Cobertura int
  
SELECT @Cod_Cobertura = Id_Cobertura -- asignaci�n
FROM Consultorio_Medico.dbo.Paciente
where Id_Paciente = @Cod_Paciente -- comparaci�n

RETURN ISNULL(@Cod_Cobertura,0)

GO


