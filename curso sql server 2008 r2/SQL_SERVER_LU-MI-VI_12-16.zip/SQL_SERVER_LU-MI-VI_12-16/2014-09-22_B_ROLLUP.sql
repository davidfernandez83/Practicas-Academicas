-- ROLLUP
---------

-- GROUP BY simple (sin ROLLUP)
-------------------------------
-- Listar la cantidad de turnos, agrupados por Cobertura y Paciente
SELECT C.RNOS, P.Nro_Carnet, COUNT(*) AS [Cant Turnos]
FROM Consultorio_Medico.dbo.Cobertura_Social C
inner join Consultorio_Medico.dbo.Paciente P
  on C.Id_Cobertura = P.Id_Cobertura
inner join Consultorio_Medico.dbo.Turno T
  on P.Id_Paciente = T.Id_Paciente
GROUP BY C.RNOS, P.Nro_Carnet
ORDER BY 1, 2
/*
RNOS        Nro_Carnet      Cant Turnos
----------- --------------- -----------
1904        345678          1
1904        765432          2
3504        876543          2
100809      456789          2
102904      876543          1
104108      567890          2
105507      098765          2
105507      109876          2
105507      678901          1
105507      789012          1
110503      210987          2
111605      321098          1
111605      890123          1
111605      901234          1
117207      012345          1
118606      543210          1
119906      357924          1
121309      429753          1

(18 filas afectadas)
*/

-- GROUP BY con ROLLUP sobre una sola dimensi�n (Cobertura-Paciente)
--------------------------------------------------------------------
-- Listar la cantidad de turnos, agrupados por Cobertura y Paciente,
-- pero mostrando adem�s un subtotal por cada cobertura y un total general
SELECT C.RNOS, P.Nro_Carnet, COUNT(*) AS [Cant Turnos]
FROM Consultorio_Medico.dbo.Cobertura_Social C
inner join Consultorio_Medico.dbo.Paciente P
  on C.Id_Cobertura = P.Id_Cobertura
inner join Consultorio_Medico.dbo.Turno T
  on P.Id_Paciente = T.Id_Paciente
GROUP BY ROLLUP (C.RNOS, P.Nro_Carnet)
ORDER BY 1, 2
/*
RNOS        Nro_Carnet      Cant Turnos
----------- --------------- -----------
NULL        NULL            25
1904        NULL            3
1904        345678          1
1904        765432          2
3504        NULL            2
3504        876543          2
100809      NULL            2
100809      456789          2
102904      NULL            1
102904      876543          1
104108      NULL            2
104108      567890          2
105507      NULL            6
105507      098765          2
105507      109876          2
105507      678901          1
105507      789012          1
110503      NULL            2
110503      210987          2
111605      NULL            3
111605      321098          1
111605      890123          1
111605      901234          1
117207      NULL            1
117207      012345          1
118606      NULL            1
118606      543210          1
119906      NULL            1
119906      357924          1
121309      NULL            1
121309      429753          1

(31 filas afectadas)
*/


-- GROUP BY con ROLLUP sobre 2 dimensiones
-- (Cobertura-Paciente) y (A�o-Mes-D�a del turno)
-------------------------------------------------
-- Listar la cantidad de turnos, agrupados por Cobertura, Paciente, A�o, Mes y D�a,
-- pero mostrando adem�s subtotales cruzados entre las dimensiones de 
-- cobertura-paciente y de a�o-mes-d�a
SELECT C.RNOS, P.Nro_Carnet,
  DATEPART(YEAR,Fecha_turno) AS [A�o],
  DATEPART(MONTH,Fecha_turno) AS [Mes],
  DATEPART(DAY,Fecha_turno) AS [D�a],
  COUNT(*) AS [Cant Turnos]
FROM Consultorio_Medico.dbo.Cobertura_Social C
inner join Consultorio_Medico.dbo.Paciente P
  on C.Id_Cobertura = P.Id_Cobertura
inner join Consultorio_Medico.dbo.Turno T
  on P.Id_Paciente = T.Id_Paciente
GROUP BY ROLLUP (C.RNOS, P.Nro_Carnet),
         ROLLUP (DATEPART(YEAR,Fecha_turno),
                 DATEPART(MONTH,Fecha_turno),
                 DATEPART(DAY,Fecha_turno))
ORDER BY 1, 2, 3, 4, 5


-- EJERCICIO 3:
-- Listar la cantidad de turnos, agrupados por M�dico y Cobertura del paciente,
-- pero mostrando adem�s un subtotal por cada m�dico y un total general.
-- Incluir tambi�n a los pacientes que se atienden por privado

