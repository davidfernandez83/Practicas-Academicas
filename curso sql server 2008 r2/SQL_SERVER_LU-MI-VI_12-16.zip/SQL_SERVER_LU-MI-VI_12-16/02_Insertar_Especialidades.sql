USE [Consultorio_Medico]
GO

INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('CLINICA MEDICA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('CARDIOLOGIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('TRAUMATOLOGIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('OBSTETRICIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('DERMATOLOGIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('NEUROLOGIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('NUTRICION')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('OFTALMOLOGIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('OTORRINOLARINGOLOGIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('PEDIATRIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('UROLOGIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('GASTROENTEROLOGIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('GINECOLOGIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('PSIQUIATRIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('REUMATOLOGIA')
INSERT INTO [dbo].[Especialidad] ([Nombre]) VALUES ('ENDOCRINOLOGIA')
GO
