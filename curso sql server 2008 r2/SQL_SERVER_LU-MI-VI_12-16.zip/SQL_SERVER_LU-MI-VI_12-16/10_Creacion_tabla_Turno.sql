USE [Consultorio_Medico]
GO

/****** Object:  Table [dbo].[Turno]    Script Date: 09/19/2014 10:30:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Turno](
	[Fecha_turno] [date] NOT NULL,
	[Hora_turno] [time](0) NOT NULL,
	[Id_Medico] [int] NOT NULL,
	[Id_Paciente] [int] NULL,
	[Nro_Consultorio] [smallint] NULL,
	[Id_Especialidad] [smallint] NULL,
	[Observaciones] [nvarchar](200) NULL,
	[Fecha_reserva] [smalldatetime] NOT NULL,
 CONSTRAINT [PK_Turno] PRIMARY KEY CLUSTERED 
(
	[Fecha_turno] ASC,
	[Hora_turno] ASC,
	[Id_Medico] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Turno]  WITH CHECK ADD  CONSTRAINT [FK_Turno_Especialidad] FOREIGN KEY([Id_Especialidad])
REFERENCES [dbo].[Especialidad] ([Id_Especialidad])
GO

ALTER TABLE [dbo].[Turno] CHECK CONSTRAINT [FK_Turno_Especialidad]
GO

ALTER TABLE [dbo].[Turno]  WITH CHECK ADD  CONSTRAINT [FK_Turno_Medico] FOREIGN KEY([Id_Medico])
REFERENCES [dbo].[Medico] ([Id_Medico])
GO

ALTER TABLE [dbo].[Turno] CHECK CONSTRAINT [FK_Turno_Medico]
GO

ALTER TABLE [dbo].[Turno]  WITH CHECK ADD  CONSTRAINT [FK_Turno_Paciente] FOREIGN KEY([Id_Paciente])
REFERENCES [dbo].[Paciente] ([Id_Paciente])
GO

ALTER TABLE [dbo].[Turno] CHECK CONSTRAINT [FK_Turno_Paciente]
GO

ALTER TABLE [dbo].[Turno] ADD  CONSTRAINT [DF_Turno_Fecha_reserva]  DEFAULT (getdate()) FOR [Fecha_reserva]
GO


