-- Reasignar todos los turnos del d�a 24-09-2014 del m�dico
-- con apellido 'Perez Rodriguez', para el m�dico con apellido 'Borocoto'

