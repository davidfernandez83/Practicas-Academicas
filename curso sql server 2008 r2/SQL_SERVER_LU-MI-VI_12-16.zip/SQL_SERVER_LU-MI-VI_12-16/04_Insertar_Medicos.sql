﻿USE [Consultorio_Medico]
GO

INSERT INTO [dbo].[Medico] ([Apellido],[Nombre],[Direccion_Calle],[Direccion_Puerta],[Direccion_Piso],[Direccion_Depto],[Direccion_Localidad],[Direccion_CP],[Direccion_Id_Provincia],[Telefono_particular],[Telefono_celular],[Nro_Matricula],[Nro_Documento]) VALUES ('Perez Rodriguez', 'Juan Manuel', 'Av. Avellaneda', '2255      ', '4         ', 'A         ', 'CABA', 'C1406CRU', 'CF', '1144448888 ', '1155559999 ', '1234/567       ', '12345678       ')
INSERT INTO [dbo].[Medico] ([Apellido],[Nombre],[Direccion_Calle],[Direccion_Puerta],[Direccion_Piso],[Direccion_Depto],[Direccion_Localidad],[Direccion_CP],[Direccion_Id_Provincia],[Telefono_particular],[Telefono_celular],[Nro_Matricula],[Nro_Documento]) VALUES ('Borocoto', 'Andres Raul', 'Av. Corrientes', '348       ', '2         ', '          ', 'San Miguel', 'B1663VCD', 'BA', '2924777888 ', '1122224444 ', '2345/678       ', '18901234       ')
INSERT INTO [dbo].[Medico] ([Apellido],[Nombre],[Direccion_Calle],[Direccion_Puerta],[Direccion_Piso],[Direccion_Depto],[Direccion_Localidad],[Direccion_CP],[Direccion_Id_Provincia],[Telefono_particular],[Telefono_celular],[Nro_Matricula],[Nro_Documento]) VALUES ('Cormillot', 'Eduardo', 'Pasteur', '633       ', NULL, NULL, 'CABA', 'C1028AAM', 'CF', NULL, NULL, '3456/789       ', '25678901       ')
GO

