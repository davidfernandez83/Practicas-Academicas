-- COMPUTE y COMPUTE BY (se remplazan ambos por ROLLUP)
-----------------------

-- Listar apellido, nombre y edad de todos los pacientes,
-- orden�ndolos por c�digo de cobertura,
-- y mostrando para cada cobertura la cantidad de pacientes y su edad promedio.
-- Mostrar tambi�n al final la cantidad total de pacientes y su edad promedio
SELECT P.Id_Cobertura, isnull(C.Denominacion,'PRIVADO'),
  P.Apellido, P.Nombre, DATEDIFF(month,P.Fecha_nacimiento,getdate())/12 as Edad
FROM Consultorio_Medico.dbo.Paciente P
  LEFT JOIN Consultorio_Medico.dbo.Cobertura_Social C
    ON P.Id_Cobertura = C.Id_Cobertura
ORDER BY 1, 2
-- COMPUTE BY: subtotales por cada P.Id_Cobertura
COMPUTE COUNT(P.Apellido), AVG(DATEDIFF(month,P.Fecha_nacimiento,getdate())/12)
  BY P.Id_Cobertura
-- COMPUTE: una sola fila al final, con total para todas las filas
COMPUTE COUNT(P.Apellido), AVG(DATEDIFF(month,P.Fecha_nacimiento,getdate())/12)


-- LA CONSULTA DE ARRIBA, EQUIVALDRIA A "UNIR" TODAS LAS SIGUIENTES CONSULTAS
-----------------------------------------------------------------------------
SELECT P.Id_Cobertura, isnull(C.Denominacion,'PRIVADO'),
  P.Apellido, P.Nombre, DATEDIFF(month,P.Fecha_nacimiento,getdate())/12 as Edad
FROM Consultorio_Medico.dbo.Paciente P
  LEFT JOIN Consultorio_Medico.dbo.Cobertura_Social C
    ON P.Id_Cobertura = C.Id_Cobertura
ORDER BY 1, 2

SELECT P.Id_Cobertura, isnull(C.Denominacion,'PRIVADO'),
  COUNT(P.Apellido), AVG(DATEDIFF(month,P.Fecha_nacimiento,getdate())/12)
FROM Consultorio_Medico.dbo.Paciente P
  LEFT JOIN Consultorio_Medico.dbo.Cobertura_Social C
    ON P.Id_Cobertura = C.Id_Cobertura
GROUP BY P.Id_Cobertura, isnull(C.Denominacion,'PRIVADO')
ORDER BY 1, 2

SELECT
  COUNT(P.Apellido), AVG(DATEDIFF(month,P.Fecha_nacimiento,getdate())/12)
FROM Consultorio_Medico.dbo.Paciente P
  LEFT JOIN Consultorio_Medico.dbo.Cobertura_Social C
    ON P.Id_Cobertura = C.Id_Cobertura
    

-- EJERCICIO 1:
-- Listar todos los turnos del mes de septiembre/2014, ordenados por
-- denominaci�n de la cobertura social del paciente, fecha y hora del turno,
-- junto con la cantidad de turnos por cada cobertura
-- Mostrar en el detalle la Denominacion y el RNOS de la cobertura,
-- fecha y hora del turno, y Apellido, Nombre y Nro_Carnet del paciente


-- EJERCICIO 2:
-- Listar todos los pacientes distintos atendidos por el m�dico
-- de apellido Cormillot, junto con sus edades m�nima, m�xima y promedio

