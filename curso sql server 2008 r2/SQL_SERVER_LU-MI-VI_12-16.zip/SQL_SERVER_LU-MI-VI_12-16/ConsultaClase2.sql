use Consultorio_Medico
select Apellido + ' ' + substring (Nombre,1,1)+'.'  as 'Nombre Apellido', dbo.Medico.Nro_Matricula, 
Direccion_Calle + Direccion_Puerta + ISNULL(Direccion_Piso,'') as DireccionyPiso 
from dbo.Medico

