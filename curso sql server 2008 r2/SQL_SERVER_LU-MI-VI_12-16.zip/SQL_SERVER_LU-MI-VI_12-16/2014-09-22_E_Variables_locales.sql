/*
Primer batch del script
-----------------------
- Declaraci�n de variable local
- Asignaci�n por SET
- Uso como valor de comparaci�n 
*/

DECLARE @Cod_Medico int

SET @Cod_Medico = 1

SELECT Apellido+', '+Nombre
FROM Consultorio_Medico.dbo.Medico
WHERE Id_Medico = @Cod_Medico

GO -- Fin del primer batch


/*
Segundo batch del script
------------------------
- Declaraci�n de variables locales
- Asignaci�n por SELECT
*/

DECLARE
  @Apel varchar(80),
  @Nom varchar(80),
  @NombreCompleto varchar(162)

SELECT @Apel = Apellido, @Nom = Nombre FROM Consultorio_Medico.dbo.Paciente
where Id_Paciente = 20

SELECT @NombreCompleto = rtrim(@Apel) + ', ' + rtrim(@Nom)

SELECT @NombreCompleto

GO -- Fin del segundo batch


/*
Tercer batch del script
-----------------------
- Declaraci�n de variables locales
- Asignaci�n por SET y por EXEC
*/

DECLARE @Cobertura int, @Paciente int
SET @Paciente = 2
EXEC @Cobertura = Obtener_Cobertura_Paciente @Paciente
SELECT @Cobertura

GO -- Fin del tercer batch
