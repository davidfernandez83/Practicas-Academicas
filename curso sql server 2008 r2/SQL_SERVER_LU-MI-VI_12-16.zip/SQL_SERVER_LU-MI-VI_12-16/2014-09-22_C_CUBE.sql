-- CUBE
-------

-- GROUP BY con CUBE sobre Cobertura-Paciente-Mes-D�a
-----------------------------------------------------
-- Listar la cantidad de turnos, agrupados por Cobertura, Paciente, Mes y D�a,
-- pero mostrando adem�s subtotales para todas las combinaciones de esos campos 
SELECT C.RNOS, P.Nro_Carnet,
  DATEPART(MONTH,Fecha_turno) AS [Mes],
  DATEPART(DAY,Fecha_turno) AS [D�a],
  COUNT(*) AS [Cant Turnos]
FROM Consultorio_Medico.dbo.Cobertura_Social C
inner join Consultorio_Medico.dbo.Paciente P
  on C.Id_Cobertura = P.Id_Cobertura
inner join Consultorio_Medico.dbo.Turno T
  on P.Id_Paciente = T.Id_Paciente
GROUP BY CUBE (C.RNOS, P.Nro_Carnet,
               DATEPART(MONTH,Fecha_turno),
               DATEPART(DAY,Fecha_turno))
ORDER BY 1, 2, 3, 4


-- EJERCICIO 4:
-- Listar la cantidad de turnos, agrupados por M�dico y por Paciente,
-- mostrando sub-totales para todas las combinaciones posibles, y un total general.

