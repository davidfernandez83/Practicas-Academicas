﻿USE [Consultorio_Medico]
GO

INSERT INTO [dbo].[Medico_Especialidad] ([Id_Medico],[Id_Especialidad]) VALUES (1 , 1 )
INSERT INTO [dbo].[Medico_Especialidad] ([Id_Medico],[Id_Especialidad]) VALUES (1 , 5 )
INSERT INTO [dbo].[Medico_Especialidad] ([Id_Medico],[Id_Especialidad]) VALUES (2 , 10)
INSERT INTO [dbo].[Medico_Especialidad] ([Id_Medico],[Id_Especialidad]) VALUES (3 , 7 )
INSERT INTO [dbo].[Medico_Especialidad] ([Id_Medico],[Id_Especialidad]) VALUES (3 , 16)
GO

