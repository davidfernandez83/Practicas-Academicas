-- Insertar un registro en la tabla TURNO
-- con la clausula VALUES

-- Ejemplo: 
INSERT INTO Consultorio_Medico.dbo.Turno
 (Fecha_turno, Hora_turno, Id_Medico, Id_Paciente, Nro_Consultorio)
VALUES
 (CONVERT(date,'20140924',112), '11:00', 1, 10, 5)

-- Insertar 3 registros en la tabla TURNO
-- con la clausula VALUES
INSERT INTO Consultorio_Medico.dbo.Turno
 (Fecha_turno, Hora_turno, Id_Medico, Id_Paciente, Nro_Consultorio)
VALUES
 (CONVERT(date,'20140924',112), '11:15', 1, 12, 5),
 (CONVERT(date,'20140924',112), '11:30', 1, 5, 5),
 (CONVERT(date,'20140924',112), '11:45', 1, 2, 5)


-- Insertar 3 registros en la tabla TURNO
-- con la clausula VALUES
INSERT INTO Consultorio_Medico.dbo.Turno
 (Fecha_turno, Hora_turno, Id_Medico, Id_Paciente, Nro_Consultorio)
VALUES
 (CONVERT(date,'20140924',112), '11:15', 1, 12, 5),
 (CONVERT(date,'20140924',112), '11:30', 1, 5, 5),
 (CONVERT(date,'20140924',112), '11:45', 1, 2, 5)


-- Insertar registros en la tabla TURNO utilizando SELECT
---------------------------------------------------------

-- Agregar un turno para el paciente con apellido 'Gaeta'
-- para las 9 hs del d�a 25-09-2014, con el m�dico de apellido 'Cormillot'
-- en el consultorio Nro 3


-- Agregar un turno para el paciente con n�mero de documento '12345678'
-- para las 9 hs del d�a 25-09-2014, con el m�dico que tiene matr�cula '2345/678'
-- en el consultorio Nro 2



