UPDATE Consultorio_Medico.dbo.Paciente
SET Fecha_nacimiento =  DATEADD(month,
      convert(int,left(Nro_Documento,3))%500,
      dateadd(year,-60,GETDATE())),
    Nro_Carnet = SUBSTRING(Nro_Documento,2,6)
