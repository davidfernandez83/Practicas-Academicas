package net.sgoliver.android.gridview;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	private TextView lblNumeroUno;
	private TextView lblNumeroDos;
	private Integer NumUno;
	private Integer NumDos;
	
	private TextView lblResultado;
	private GridView grdOpciones;
	
	private Button BtnSuma;
	private Button BtnResta;
	private Button BtnDiv;
	private Button BtnMult;
	private Button BtnRdo;
	
	private RadioButton rbUno;
	private RadioButton rbDos;
	
	//private String[] datos = new String[25];
	private String[] datos = new String[9];

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        //for(int i=1; i<=25; i++) datos[i-1] = "Dato " + i;
        for(int i=1; i<=9; i++) datos[i-1] = ""+  i + "";
        
        ArrayAdapter<String> adaptador = 
        	new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, datos);
        
        lblNumeroUno = (TextView)findViewById(R.id.LblNumeroUno);
        lblNumeroDos = (TextView)findViewById(R.id.LblNumeroDos);
        rbUno = (RadioButton)findViewById(R.id.radioButton1);
        rbDos = (RadioButton)findViewById(R.id.radioButton2);	
        grdOpciones = (GridView)findViewById(R.id.GridOpciones);
        BtnSuma = (Button)findViewById(R.id.button1);
        BtnResta = (Button)findViewById(R.id.button2);
        BtnDiv = (Button)findViewById(R.id.button3);
        BtnMult = (Button)findViewById(R.id.button4);
        BtnRdo =  (Button)findViewById(R.id.button5);
        lblResultado = (TextView)findViewById(R.id.lblResultado);
        
        grdOpciones.setOnItemClickListener(
            	new AdapterView.OnItemClickListener() {
        		public void onItemClick(AdapterView<?> parent,
        			android.view.View v, int position, long id) {
        			
           			//	lblMensaje.setText("Opci�n seleccionada: " + datos[position]);
        			if(rbUno.isChecked())
        				 lblNumeroUno.setText(lblNumeroUno.getText() + datos[position]); 
        			else
        				lblNumeroDos.setText(lblNumeroDos.getText() + datos[position]); 
        		}
        });
        
        grdOpciones.setAdapter(adaptador);
        
        BtnSuma.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//lblMensaje = (TextView)findViewById(R.id.LblCuenta);
				
				NumUno =  Integer.parseInt( lblNumeroUno.getText().toString()) ;
				NumDos =  Integer.parseInt( lblNumeroDos.getText().toString()) ;
				NumUno = NumUno + NumDos;
				lblResultado.setText("Resultado:" + NumUno ) ;
				
				
			}
		});
        
        BtnResta.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
			//	lblMensaje.setText(lblMensaje.getText() + "-");
			}
		});
        
        BtnDiv.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
			//	lblMensaje.setText(lblMensaje.getText() + "/");
			}
		});
        
       BtnMult.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
		//	lblMensaje.setText(lblMensaje.getText() + "*");
		}
	}); 
       
       BtnRdo.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
		    lblNumeroUno.setText("");
	        lblNumeroDos.setText(""); 
	    
		   lblResultado.setText("Resultado:" ) ;  	
		}
	});
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    
}
