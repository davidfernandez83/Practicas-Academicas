/** Automatically generated file. DO NOT MODIFY */
package net.sgoliver.android.gridview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}