package net.sgoliver.android.listview;

public class Titular 
{
	private String titulo;
	private String subtitulo;
	private String autor;

	public Titular(String tit, String sub, String aut){
		titulo = tit;
		subtitulo = sub;
		autor = aut;
	}
	
	public String getTitulo(){
		return titulo;
	}
	
	public String getSubtitulo(){
		return subtitulo;
	}
	
	public String getAutor(){
		return autor;
	}
}
